# Configuration file for API keys and other settings

API_KEY = 'your_api_key'
API_SECRET = 'your_api_secret'
TRADING_PAIR = 'BTC_USDT'
GRID_SIZE = 0.002
STOP_LOSS_PERCENTAGE = 0.05
TAKE_PROFIT_PERCENTAGE = 0.05
MAX_DRAWDOWN = 0.1
